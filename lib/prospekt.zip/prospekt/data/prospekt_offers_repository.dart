import '../models/prospekt_offer.dart';
import 'offers_db.dart';
import '../services/offers_sync_service.dart';

class ProspektOffersRepository {
  final OffersDb _db;
  final OffersSyncService _sync;

  ProspektOffersRepository({
    OffersDb? db,
    required OffersSyncService sync,
  })  : _db = db ?? OffersDb.instance,
        _sync = sync;

  Future<int> syncAll() => _sync.syncAll();

  Future<int> replaceAllFromServer() => _sync.replaceAllFromServer();

  Future<int> localCount() => _db.count();

  Future<List<String>> listMarkets() => _db.listMarkets();

  Future<List<ProspektOffer>> searchOffers({
    required String query,
    String? market,
    double? minPrice,
    double? maxPrice,
    int limit = 100,
    int offset = 0,
  }) {
    return _db.search(
      query: query,
      market: market,
      minPrice: minPrice,
      maxPrice: maxPrice,
      limit: limit,
      offset: offset,
    );
  }

  Future<int> deleteAllLocal() => _db.deleteAll();
}