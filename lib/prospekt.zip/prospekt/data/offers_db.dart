import 'dart:async';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../models/prospekt_offer.dart';

class OffersDb {
  OffersDb._();

  static final OffersDb instance = OffersDb._();

  Database? _db;

  Future<Database> get database async {
    final existing = _db;
    if (existing != null) return existing;
    final db = await _open();
    _db = db;
    return db;
  }

  Future<Database> _open() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, 'offers.sqlite');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
CREATE TABLE offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  server_id INTEGER,
  market TEXT NOT NULL,
  title TEXT NOT NULL,
  price_eur REAL NOT NULL,
  quantity TEXT NOT NULL,
  created_at TEXT,
  updated_at TEXT
);
''');

        // Falls server_id vorhanden ist, ist es idealer Unique-Key:
        await db.execute('CREATE UNIQUE INDEX idx_offers_server_id ON offers(server_id) WHERE server_id IS NOT NULL;');

        // Fallback-Dedupe für Angebote ohne server_id:
        await db.execute('CREATE INDEX idx_offers_market_title ON offers(market, title);');
        await db.execute('CREATE INDEX idx_offers_price ON offers(price_eur);');
      },
    );
  }

  Future<void> close() async {
    final db = _db;
    _db = null;
    if (db != null) await db.close();
  }

  Future<int> upsertOffer(ProspektOffer offer) async {
    final db = await database;

    // 1) Wenn server_id da ist: upsert über server_id
    if (offer.serverId != null) {
      final rows = await db.query(
        'offers',
        columns: ['id'],
        where: 'server_id = ?',
        whereArgs: [offer.serverId],
        limit: 1,
      );

      if (rows.isNotEmpty) {
        final id = rows.first['id'] as int;
        await db.update(
          'offers',
          offer.toDbMap(),
          where: 'id = ?',
          whereArgs: [id],
        );
        return id;
      }

      return db.insert('offers', offer.toDbMap());
    }

    // 2) Fallback: dedupe über market+title+price+quantity
    final rows = await db.query(
      'offers',
      columns: ['id'],
      where: 'market = ? AND title = ? AND price_eur = ? AND quantity = ?',
      whereArgs: [offer.market, offer.title, offer.priceEur, offer.quantity],
      limit: 1,
    );

    if (rows.isNotEmpty) {
      final id = rows.first['id'] as int;
      await db.update(
        'offers',
        offer.toDbMap(),
        where: 'id = ?',
        whereArgs: [id],
      );
      return id;
    }

    return db.insert('offers', offer.toDbMap());
  }

  Future<void> replaceAll(List<ProspektOffer> offers) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('offers');
      for (final o in offers) {
        await txn.insert('offers', o.toDbMap());
      }
    });
  }

  Future<int> deleteAll() async {
    final db = await database;
    return db.delete('offers');
  }

  Future<List<ProspektOffer>> search({
    required String query,
    String? market,
    double? minPrice,
    double? maxPrice,
    int limit = 100,
    int offset = 0,
  }) async {
    final db = await database;

    final q = query.trim();
    final args = <Object?>[];
    final whereParts = <String>[];

    if (q.isNotEmpty) {
      // einfache LIKE-Suche in title
      whereParts.add('LOWER(title) LIKE ?');
      args.add('%${q.toLowerCase()}%');
    }

    if (market != null && market.trim().isNotEmpty) {
      whereParts.add('market = ?');
      args.add(market.trim());
    }

    if (minPrice != null) {
      whereParts.add('price_eur >= ?');
      args.add(minPrice);
    }

    if (maxPrice != null) {
      whereParts.add('price_eur <= ?');
      args.add(maxPrice);
    }

    final where = whereParts.isEmpty ? null : whereParts.join(' AND ');

    final rows = await db.query(
      'offers',
      where: where,
      whereArgs: args,
      orderBy: 'price_eur ASC, title ASC',
      limit: limit,
      offset: offset,
    );

    return rows.map(ProspektOffer.fromDbMap).toList();
  }

  Future<List<String>> listMarkets() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT DISTINCT market FROM offers ORDER BY market ASC;');
    return rows.map((r) => (r['market'] ?? '').toString()).where((s) => s.isNotEmpty).toList();
  }

  Future<int> count() async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM offers;');
    return (rows.first['c'] as int?) ?? 0;
  }
}