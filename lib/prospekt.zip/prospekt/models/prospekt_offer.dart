class ProspektOffer {
  final int? id; // lokale DB id
  final int? serverId; // serverseitige id (falls vorhanden)
  final String market;
  final String title;
  final double priceEur;
  final String quantity;

  final DateTime? createdAt;
  final DateTime? updatedAt;

  const ProspektOffer({
    this.id,
    this.serverId,
    required this.market,
    required this.title,
    required this.priceEur,
    required this.quantity,
    this.createdAt,
    this.updatedAt,
  });

  ProspektOffer copyWith({
    int? id,
    int? serverId,
    String? market,
    String? title,
    double? priceEur,
    String? quantity,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return ProspektOffer(
      id: id ?? this.id,
      serverId: serverId ?? this.serverId,
      market: market ?? this.market,
      title: title ?? this.title,
      priceEur: priceEur ?? this.priceEur,
      quantity: quantity ?? this.quantity,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  static DateTime? _dt(dynamic v) {
    if (v == null) return null;
    final s = v.toString().trim();
    if (s.isEmpty) return null;
    return DateTime.tryParse(s);
  }

  static double _asDouble(dynamic v) {
    if (v == null) return 0.0;
    if (v is num) return v.toDouble();
    final s = v.toString().trim().replaceAll(',', '.');
    return double.tryParse(s) ?? 0.0;
  }

  static int? _asInt(dynamic v) {
    if (v == null) return null;
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse(v.toString().trim());
  }

  factory ProspektOffer.fromJson(Map<String, dynamic> json) {
    return ProspektOffer(
      serverId: _asInt(json['id']),
      market: (json['market'] ?? '').toString().trim(),
      title: (json['title'] ?? '').toString().trim(),
      priceEur: _asDouble(json['price_eur']),
      quantity: (json['quantity'] ?? '').toString().trim(),
      createdAt: _dt(json['created_at']),
      updatedAt: _dt(json['updated_at']),
    );
  }

  Map<String, dynamic> toDbMap() {
    return <String, dynamic>{
      'server_id': serverId,
      'market': market,
      'title': title,
      'price_eur': priceEur,
      'quantity': quantity,
      'created_at': createdAt?.toIso8601String(),
      'updated_at': updatedAt?.toIso8601String(),
    };
  }

  factory ProspektOffer.fromDbMap(Map<String, dynamic> row) {
    return ProspektOffer(
      id: row['id'] as int?,
      serverId: row['server_id'] as int?,
      market: (row['market'] ?? '').toString(),
      title: (row['title'] ?? '').toString(),
      priceEur: (row['price_eur'] is num)
          ? (row['price_eur'] as num).toDouble()
          : double.tryParse((row['price_eur'] ?? '0').toString()) ?? 0.0,
      quantity: (row['quantity'] ?? '').toString(),
      createdAt: row['created_at'] != null
          ? DateTime.tryParse(row['created_at'].toString())
          : null,
      updatedAt: row['updated_at'] != null
          ? DateTime.tryParse(row['updated_at'].toString())
          : null,
    );
  }
}