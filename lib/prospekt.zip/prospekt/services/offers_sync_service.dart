import '../data/offers_db.dart';
import '../models/prospekt_offer.dart';
import 'prospekt_api_client.dart';

class OffersSyncService {
  final OffersDb _db;
  final ProspektApiClient _api;

  OffersSyncService({
    OffersDb? db,
    required ProspektApiClient api,
  })  : _db = db ?? OffersDb.instance,
        _api = api;

  /// Holt alle Angebote vom Server und upsertet sie lokal.
  /// Für maximale Stabilität und Einfachheit.
  Future<int> syncAll() async {
    final remote = await _api.fetchOffers();
    var count = 0;
    for (final o in remote) {
      if (o.market.trim().isEmpty || o.title.trim().isEmpty) continue;
      if (o.priceEur <= 0) continue;
      await _db.upsertOffer(o);
      count++;
    }
    return count;
  }

  /// Harte Variante: lokal komplett ersetzen.
  /// Kann sinnvoll sein, wenn du serverseitig wirklich „Source of Truth“ bist.
  Future<int> replaceAllFromServer() async {
    final remote = await _api.fetchOffers();
    final cleaned = <ProspektOffer>[];
    for (final o in remote) {
      if (o.market.trim().isEmpty || o.title.trim().isEmpty) continue;
      if (o.priceEur <= 0) continue;
      cleaned.add(o);
    }
    await _db.replaceAll(cleaned);
    return cleaned.length;
  }
}