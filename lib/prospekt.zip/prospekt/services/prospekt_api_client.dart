import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/prospekt_offer.dart';

class ProspektApiClient {
  // Beispiel: http://10.171.219.157:8000
  final String baseUrl;
  final http.Client _client;

  ProspektApiClient({
    required this.baseUrl,
    http.Client? client,
  }) : _client = client ?? http.Client();

  Uri _u(String path, [Map<String, String>? qp]) {
    final b = baseUrl.endsWith('/') ? baseUrl.substring(0, baseUrl.length - 1) : baseUrl;
    final p = path.startsWith('/') ? path : '/$path';
    return Uri.parse('$b$p').replace(queryParameters: qp);
  }

  Future<List<ProspektOffer>> fetchOffers() async {
    // Standard: read-only endpoint
    final uri = _u('/api/offers');

    final res = await _client.get(uri, headers: {
      'Accept': 'application/json',
    });

    if (res.statusCode != 200) {
      throw Exception('fetchOffers failed: HTTP ${res.statusCode}: ${res.body}');
    }

    final decoded = jsonDecode(res.body);

    // Erlaubt: { "offers": [...] } oder direkt [...]
    final list = (decoded is Map<String, dynamic>)
        ? (decoded['offers'] as List<dynamic>? ?? const <dynamic>[])
        : (decoded is List ? decoded : const <dynamic>[]);

    return list
        .whereType<Map>()
        .map((m) => ProspektOffer.fromJson(Map<String, dynamic>.from(m)))
        .toList();
  }

  void close() {
    _client.close();
  }
}